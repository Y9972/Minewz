$(document).ready(function(){
	$("#down-static").click(function(){
		var targetUrl = $("#targetUrl").val();
		var regval = $("#regval").val();
		if((targetUrl.indexOf("https://")==-1)&&(targetUrl.indexOf("http://")==-1)){
			alert("下载链接请带上 http:// 或 htts://");
			return ;
		}
		var page = chrome.extension.getBackgroundPage();//获取后台页面
		page.startDown(targetUrl,regval);
	});
});