/*注入于当前页面内容的js*/

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    if (request.funcName == "downStatic"){
    	let parm1 = request.parm1;
    	let parm2 = request.parm2;
    	let parm3 = request.parm3;
    	downStatic(parm1,parm2,parm3);
    }
  });

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    if (request.funcName == "getStatus"){
    	 sendResponse({status: document.readyState});
    }
  });


//默认正则配置
var OrdinaryRegval = "files/article/xiaoshuo/(\d+)/(\d+)";


//下载当前网页的所有静态资源
function downStatic(urlArr , regval , tid){
	 var zip = new JSZip();//zip对象
	 var imgBase64 = [];
	 var resCount = 0;
	for(var i=0;i<urlArr.length;i++){
		let urlTid = urlArr[i].split("|||")[0];
		let urlOne = urlArr[i].split("|||")[1];
		let ext = getExt(getUrlFileName(urlOne));
		if(urlTid != tid|| !typeMatch(ext)){
			resCount++;
			continue;
		}

		if(ext==".js"||ext==".css"){
		              getScriptCss(urlOne)
		                .then(function(data){
		                    if(data=="false"){
		                        resCount++;
		                    }else{
				var route = getFileRoute(urlOne);
				var folder = zip.folder(route);
		                        folder.file(getUrlFileName(urlOne),data);
		                        resCount++;
		                    }
		                },function(err){});
		}else{
			if(regval==""||regval==null){
				regval = OrdinaryRegval;
			}
			var reg = new RegExp(regval);
			if(reg.test(urlOne)){
				resCount++;
				continue;
			}
			getBase64(urlOne)
		                .then(function(base64){
		                	if(base64!="false"){
		                	var route = getFileRoute(urlOne);
				var folder = zip.folder(route);
				folder.file(getUrlFileName(urlOne), base64.substring(22), {base64: true});
				resCount++;
		                	}else{
		                		resCount++;
		                	}
		                },function(err){

		                });
		}
	}

	function tt(){
	    setTimeout(function(){
	        if(resCount == urlArr.length){
	        zip.generateAsync({type:"blob"}).then(function(content) {
	                saveAs(content, "static.zip");
	            });
	        }else{
	            tt();
	        }

	    },200);
	}
	tt();
}


function getScriptCss(url){
  var deferred=$.Deferred();
        $.ajax({
        cache:false,
        url: url,
        success:function(data){
        deferred.resolve(data);//将base64传给done上传处理
        },
        error:function(data){
            deferred.resolve("false");
        }
    });
      return deferred.promise();//问题要让onload完成后再return sessionStorage['imgTest']
  }


//传入图片路径，返回base64
function getBase64(img){

    function getBase64Image(img,width,height) {//width、height调用时传入具体像素值，控制大小 ,不传则默认图像大小
      var canvas = document.createElement("canvas");
      canvas.width = width ? width : img.width;
      canvas.height = height ? height : img.height;
      var ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      var dataURL = canvas.toDataURL();
      return dataURL;
    }

    var deferred=$.Deferred();
    $.ajax({
        cache:false,
        url: img,
        success:function(data){
	    var image = new Image();
	    image.crossOrigin = 'Anonymous';
	    image.src = img;
	    if(img){
	      image.onload =function (){
	        deferred.resolve(getBase64Image(image));//将base64传给done上传处理
	      }
	      return deferred.promise();//问题要让onload完成后再return sessionStorage['imgTest']
	    }
        },
        error:function(data){
            deferred.resolve("false");
        }
    });
    return deferred.promise();
  }


function ajaxSaver(url , filename) {
   if(url == '' ||url==null){
   	return;
   }	
   if(filename == '' ||filename==null){
   	return;
   }
   var xhr = new XMLHttpRequest();
   xhr.open('GET', url, true);        // 也可以使用POST方式，根据接口 ，true为使用异步,false为使用同步
   xhr.responseType = "blob";    // 返回类型blob
   // 定义请求完成的处理函数，请求前也可以增加加载框/禁用下载按钮逻辑
   xhr.onload = function () {
       // 请求完成
       if (this.status === 200) {
	var alink = document.createElement('a');
	alink.href = url;
	alink.download =  getUrlFileName(filename);
	document.body.appendChild(alink);
	alink.click()
              alink.remove();
	sleep(200);
       }
   };
   // 发送ajax请求
   xhr.send()
}


//获取文件后缀名
function getExt(name){
	var ext = "";
	var i = name.lastIndexOf(".");
	if(i > -1){
	var ext = name.substring(i);
	}
	return ext;
}

//获取url里的文件名,可以处理动态链接
function getUrlFileName(url){
	if(url){
	url = url.split('?')[0] //去掉动态链接的参数
	var urlSlashCount = url.split('/').length; 
	return url.split('/')[urlSlashCount-1];
	}
	return '';
}

//判断文件是否为我们需要的静态资源
function typeMatch(ext){
	ext = ext.toLowerCase();
	var extArr = new Array(".png",".jpg",".jpeg",".bmp",".gif",".css",".js",".ico");
	var result = extArr.indexOf(ext);
	if(-1 == result){
		return false;
	}
	return true;
}

function getFileRoute(url){
	var route = url.replace(getHttpUrl(url) , "");
	if(route==""||route==null){
		return ;
	}
	var rouArr = route.split("/");
	var rouStr = "";
	for(var i=0;i<rouArr.length;i++){
		if(rouArr[i]==""||rouArr[i]==null){
			continue;
		}
		if(rouArr[i].split(".").length>1){
			continue;
		}
		rouStr += rouArr[i].toString();
		rouStr += "/";

	}
	return rouStr;
}

function getHttpUrl(url){
	if(url==null||url==""){
		return "";
	}
	return url.split('//')[0]+"//"+url.split('/')[2];
}
