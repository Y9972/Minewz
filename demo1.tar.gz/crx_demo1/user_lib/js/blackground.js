var requestArray = new Array;//请求的数组，还没经过过滤

// 填写url->与bk通信，bk调用方法打开url对应的页面-> bk取得打开页面的tid ->发送正则,tid和抓包的数据给内容脚本

//总入口
function startDown(url,regval){
       $.when(createTab(url))
       .done(function(tid){
       	chrome.tabs.get(tid , function(tab){
		getStatusToSend(tid,regval);
	})
       });
}

//轮询获取tab状态 直至状态为complete让contentScript调用下载方法
function getStatusToSend(tid,regval){
	setTimeout(
		function(){
			chrome.tabs.get(tid , function(tab){
				if(tab.status=="complete"){
					console.log("加载完成，发送数据")
					chrome.tabs.sendMessage(tid, {funcName: "downStatic", parm1:requestArray,parm2:regval,parm3:tid});
					location.reload();//发送完了把上面变量的缓存清了 不然会累加
				}else{
					getStatusToSend(tid,regval);
				}
			})
	},100);
}

function addListener(url){
chrome.webRequest.onBeforeSendHeaders.addListener(
        function(details) {
	var domain = getHttpUrl(url);//本站域名 带http
        	//判断是否为本站的域名
	if(MatchUsUrl(details.url,domain)){
		var filename = getUrlFileName(details.url);
		if(filename==""||filename==null){
			return;
		}else if(getExt(filename)!=""&&typeMatch(getExt(filename))){//判断是否为静态文件
		        	// console.log(details);
			requestArray.push(details.tabId+"|||"+details.url);
		}
	}
        },
        {urls: ["<all_urls>"]},
        ["requestHeaders"]);
}

function createTab(url){
	var dtd = $.Deferred(); 
	addListener(url);//在创建页面前就要开始监听数据 否则会出现部分请求没监听到的情况
	chrome.tabs.create({"url":url}, function(details){
		dtd.resolve(details.id);
	});
	return dtd.promise();
}
