
var obj_opt = new Vue({
    el: '#main_opt',
    data:{
        tips : 'this options html'
    }
});
