/*用于popup.html 是与用户交互的核心js*/


//事件监听 start
$(document).ready(function(){
	$("#down-static").click(function(){
		var regval = $('#regval').val();
		//获取当前浏览器选中的选项卡
		chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
		  //让内容脚本调用方法并传参数
		chrome.tabs.sendMessage(tabs[0].id, {funcName: "downStatic",parm1:requestArray,parm2:regval});
		});
	});
});

//当页面加载完成 接受页面发来的通知
chrome.extension.onMessage.addListener(
  function(request, sender, sendResponse) {
    if (request.oder == "change"){
    	$("#tits").text("");
    	$("#down-static").attr("disabled",false);
    }

  });


var requestArray = new Array();
chrome.webRequest.onBeforeSendHeaders.addListener(
        function(details) {
         	chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
		var queryUrl = tabs[0].url;
		var domain = queryUrl.split('/')[2];
	        	//判断是否为本站的域名
		if(MatchUsUrl(details.url,domain)){
			var filename = getUrlFileName(details.url);
			if(filename==""||filename==null){
				return;
			}else if(getExt(filename)!=""&&typeMatch(getExt(filename))){//判断是否为静态文件
				requestArray.push(details.url);
			}
		}
	});
        },
        {urls: ["<all_urls>"]},
        ["requestHeaders"]);
//事件监听 end


//每次打开popup询问当前页面的状态
chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
	chrome.tabs.sendMessage(tabs[0].id, {funcName: "getStatus",parm1:regval}, function(response) {
	  if(response.status == "complete"){
	    	$("#tits").text("");
	    	$("#down-static").attr("disabled",false);
	  }
	});
});

