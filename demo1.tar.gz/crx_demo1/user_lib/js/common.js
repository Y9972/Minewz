//判断是否为本站的url
function MatchUsUrl(url,domain=null){
	//判断是否为该网页的域名
	if(domain==null||domain==""){
		domain = document.domain;
	}
	if((url.indexOf(domain)) ==0){
		return true;
	}else{
		return false;
	}
}

//提取url中的带http域名
function getHttpUrl(url){
	if(url==null||url==""){
		return "";
	}
	return url.split('//')[0]+"//"+url.split('/')[2];
}

//类似于线程睡眠
function sleep(n) {
        var start = new Date().getTime();
        while (true) {
            if (new Date().getTime() - start > n) {
                break;
            }
        }
}

//获取url里的文件名,可以处理动态链接
function getUrlFileName(url){
	if(url){
	url = url.split('?')[0] //去掉动态链接的参数
	var urlSlashCount = url.split('/').length; 
	return url.split('/')[urlSlashCount-1];
	}
	return '';
}


//获取文件后缀名
function getExt(name){
	var ext = "";
	var i = name.lastIndexOf(".");
	if(i > -1){
	var ext = name.substring(i);
	}
	return ext;
}

//判断文件是否为我们需要的静态资源
function typeMatch(ext){
	ext = ext.toLowerCase();
	var extArr = new Array(".png",".jpg",".jpeg",".bmp",".gif",".css",".js",".ico");
	var result = extArr.indexOf(ext);
	if(-1 == result){
		return false;
	}
	return true;
}

//判断数组是否存在某个值
function arrIsset(arr , value){
	if(arr==null){
		return false;
	}
	var result = arr.indexOf(value);
	if(-1 == result){
		return true;
	}
	return false;
}

//去除域名 
function deleDomain(url){
	if(url==null||url==''){
		return '';
	}
	return url = url.replace(/^http:\/\/[^/]+/, "");
}
